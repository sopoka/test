
<?php



CREATE TABLE `tech_hub_db`.`main_menu` ( `id` INT(10) NOT NULL AUTO_INCREMENT , `Menu_name` VARCHAR(50) NOT NULL , PRIMARY KEY (`id`)) ENGINE = InnoDB;

INSERT INTO `main_menu`(`id`, `Menu_name`) VALUES ('1','მთავარი');
INSERT INTO `main_menu`(`id`, `Menu_name`) VALUES ('2','ჩვენ შესახებ');
INSERT INTO `main_menu`(`id`, `Menu_name`) VALUES ('3','ფოტოგალერეა');
INSERT INTO `main_menu`(`id`, `Menu_name`) VALUES ('4','კონტაქტი');


?>

