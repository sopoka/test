<?php
$connect = mysqli_connect("localhost","root","","tech_hub_db");

// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }



  if (!mysqli_set_charset($connect, "utf8")) {
    printf("Error loading character set utf8: %s\n", mysqli_error($connect));
    exit();
} else {
     mysqli_character_set_name($connect);
}
?>