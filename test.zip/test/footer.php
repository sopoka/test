<footer>
	
<br>
	<div class="footer">

		<h3>Copyright © 2019 All Rights Reserved </h3>

	</div>	

</footer>