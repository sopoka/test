<div class="menu">
  <div class="container-fluid menu1">    
    <div class="container">
   
	     <button class="navbar-toggle" data-toggle="collapse" data-target=".navCollapse">
		      <span class="glyphicon glyphicon-menu-hamburger"></span>
	     </button>
	  <div class="collapse navbar-collapse navCollapse">

        <ul class="nav nav-pills nav-justified">

          <?php 
              include("connect.php");
                $query="select * from tech_hub_db.main_menu";
                $result=mysqli_query($connect,$query);
              while($row=mysqli_fetch_assoc($result)){
            ?>

            <li><a href="?page=<?php echo $row['Menu_name']; ?>">
                   <?php echo $row['Menu_name']; ?>
              </a>
            </li>
          <?php
            }
          ?>    
  
        </ul>
<!--
   <ul class="nav nav-pills nav-justified">
           <li><a href="?page=first">მთავარი</a></li>
           <li><a href="?page=about">ჩვენ შესახებ</a></li>
           <li><a href="?page=contact">კონტაქტი</a></li>
    </ul>
	--> 
  
    </div>
    </div>
  </div> 



</div>

<div class="main container">


  <?php
              if (isset($_GET['page'])){
                
                $page=$_GET['page'];

                if (file_exists($_GET['page'].'.php')){
                    include ($_GET['page'].'.php');
                    }
                elseif (!strlen($_GET['page'])) {
                echo '404';
                 }
                 else {echo '404';
                   # code...
                 }

              }
              else {
              include ('მთავარი.php');
            }
          ?>
</div>
