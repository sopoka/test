

    
    <div class="row col-lg-6">
    			<br><br><br>
    		<div class="col-lg-6">
				<div class="form-group">	
					<label for="contact-message">სახელი * </label>
					<span><input type="text" name="your_name"  class="col-lg-3 form-control"></span>

  				</div>
			</div>

			<div class="col-lg-6">
				<div class="form-group">
					<label for="contact-message">მეილი * </label>
					<span><input type="email" name="your_email"  class="col-lg-3 form-control"></span>

				</div>
			</div>	
		
			<div class="col-lg-12"
				<div class="form-group">
					<br>
					<label for="contact-message">შეტყობინება * </label>
					<span><textarea name="your_sms" cols=50 rows=10 class="col-lg-6 form-control"></textarea></span>
			</div>			
		
			<div class="fa col-lg-12">
				<br><br>
				<h4><i class="fa fa-map-marker">&nbsp;მისამართი:</i>&nbsp; თბილისი, ჭავჭავაძის ქ. #82</h4>
				<h4><i class="fa fa-envelope">&nbsp;ელ.ფოსტა:</i>&nbsp;contact@techub.ge </h4>
				<h4><i class="fa fa-phone-square">&nbsp;მობილური:</i>&nbsp;+995 (599) 00 00 00</h4>
			</div>		
	</div>

	<div class="row col-lg-6">
			<br><br><br>
			<a class="gmw-thumbnail-map gmw-lightbox-enabled" href="https://goo.gl/maps/9T8iSa1WbEfmDNBBA"></a>
				<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2978.6830955195364!2d44.736738315677684!3d41.70577648415901!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x404473452631997d%3A0x665be3ea0bf69fd1!2zODIg4YOY4YOa4YOY4YOQIOGDreGDkOGDleGDreGDkOGDleGDkOGDq-GDmOGDoSDhg5Lhg5Dhg5vhg5bhg5jhg6Dhg5gsIOGDl-GDkeGDmOGDmuGDmOGDoeGDmA!5e0!3m2!1ska!2sge!4v1570614619921!5m2!1ska!2sge" width="100%" height="450" frameborder="0" style="border:0;" allowfullscreen="">
				</iframe>
	</div>


